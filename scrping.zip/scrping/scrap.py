import requests
from bs4 import BeautifulSoup
import csv  
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
import time
import list
departements = {
    "Maine-et-Loire": ["Angers", "Cholet", "Saumur", "Avrillé", "Trélazé"],
    "Loire-Atlantique": ["Nantes", "Saint-Nazaire", "Saint-Herblain", "Rezé", "Saint-Sébastien-sur-Loire"],
    "Vendée": ["La Roche-sur-Yon", "Les Sables-d'Olonne", "Challans", "Fontenay-le-Comte", "Les Herbiers"],
    "Gironde": ["Bordeaux", "Mérignac", "Pessac", "Talence", "Villeneuve-d'Ornon"],
    "Ille-et-Vilaine": ["Rennes", "Saint-Malo", "Fougères", "Vitré", "Cesson-Sévigné"],
    "Mayenne": ["Laval", "Mayenne", "Château-Gontier", "Évron", "Craon"],
    "Sarthe": ["Le Mans", "La Flèche", "Sablé-sur-Sarthe", "Allonnes", "Arnage"],
    "Vienne": ["Poitiers", "Châtellerault", "Buxerolles", "Loudun", "Montmorillon"],
    "Isère": ["Grenoble", "Saint-Martin-d'Hères", "Échirolles", "Vienne", "Bourgoin-Jallieu"]
}

# Chemin vers ton driver (exemple pour Chrome)
driver = webdriver.Chrome()
driver.get("https://www.anjou-tourisme.com/fr/rechercher")
time.sleep(3)

# Gestion du bouton de cookies
try:
    btncookies = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, 'axeptio_btn_dismiss')))
    btncookies.click()
    time.sleep(3)
except:
    print("Le bouton de cookies n'est pas visible.")

# Ouvrir le fichier CSV une seule fois
with open("gites.csv", "w", newline="", encoding="utf-8") as fichier:
    writer = csv.writer(fichier)
    writer.writerow(["Nom du gîte", "Lien", "département"])  # En-tête

    # Parcourir les départements
    for departement in departements.keys():
        search_bar = driver.find_element("xpath", "//input[@id='lae-search-input']") 
        search_bar.clear()
        search_bar.send_keys(f"{departement}")
        search_bar.send_keys(Keys.RETURN)  
        time.sleep(5)

        bouton = driver.find_element("xpath", '//a[@class="lae_search_category" and contains(text(), "Hébergements")]')
        bouton.click()
        time.sleep(5)

        while True:
            try:
                btnShowmore = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Afficher plus")]'))) 
                btnShowmore.click()
                time.sleep(5)
            except:
                print("Contenus complètement chargés.")
                break
        
        # Extraire les données
        soup = BeautifulSoup(driver.page_source, "html.parser")
        gitesContainer = soup.find("div", class_="lae_search_results_list")
        gites = gitesContainer.find_all("a", class_="tw-no-underline")

        for gite in gites:
            nom = gite.find("h3", class_="lae_search_result_title")
            nom = nom.text.strip() if gite.find("h3") else "Nom inconnu"
            lien = gite.get('href', "Lien inconnu")
            writer.writerow([nom, lien, departement])
            print(f"✅ Données enregistrées : {nom}")

driver.quit()
