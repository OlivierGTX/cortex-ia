import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
from openpyxl import load_workbook
import csv  
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
import time



def getMail(url):
    driver.get(url)
    time.sleep(3) 

    # Gestion du bouton de cookies
    try:
        btncookies = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, 'axeptio_btn_dismiss')))
        btncookies.click()
        time.sleep(3)
    except:
        print("Le bouton de cookies n'est pas visible.")
    

    soup = BeautifulSoup(driver.page_source, "html.parser")
    # Vérification pour "recap-infos-pratiques"
    contentRecpap = soup.find("div", class_="recap-infos-pratiques")
    lieux = contentRecpap.find('p', class_="commune").text.strip() if contentRecpap else "Lieu non trouvé"

    # Vérification pour "sidebar--content"
    formCtn = soup.find('div', class_="sidebar--content")
    email_tag = formCtn.find('a', href=lambda href: href and href.startswith('mailto:')) if formCtn else None
    email = email_tag.get('href').split('?')[0].replace('mailto:', '') if email_tag else "Email non trouvé" # Supprimer 'mailto:' et prendre la partie avant '?'

    return lieux, email

driver = webdriver.Chrome()
# Récuperation de toutes les données index 1
df = pd.read_excel('Book1.xlsx')
urls = df.iloc[:, 1].tolist()
# Liste pour stocker les données
data = []


# Récupérer les données depuis chaque page
# Récupérer les données depuis chaque page
file_path = 'mailxl2.xlsx'
for url in urls:
    lieux, email = getMail(url)
    data = [[lieux, email, url]]  # Ne pas utiliser data.clear(), recrée une liste à chaque itération
    print(lieux, email, data)

    # Convertir les données en DataFrame
    df = pd.DataFrame(data, columns=['Lieux', 'Email', 'Url'])

    try:
        if os.path.exists(file_path):
            # Charger le fichier Excel existant
            with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
                df.to_excel(writer, index=False, header=False, startrow=writer.sheets['Sheet1'].max_row)
        else:
            # Créer un nouveau fichier Excel si inexistant
            df.to_excel(file_path, index=False)
            
        print("✅ Données ajoutées avec succès !")
        
    except PermissionError:
        print("❌ ERREUR : Le fichier est déjà ouvert ailleurs. Fermez-le et réessayez.")
    except Exception as e:
        print(f"❌ Une erreur est survenue : {e}")






