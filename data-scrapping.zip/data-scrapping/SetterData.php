<?php
require __DIR__ . '/vendor/autoload.php';

use App\Db;

$db =  new Db();

$input = file_get_contents('php://input');
$data = json_decode($input, true);


if ($data === null) {
    http_response_code(400);
    echo "JSON invalide";
    exit;
}

foreach ($data as $entry) {
    $url = $entry['url'];
    $dates = $entry['dateFree'];

    $saved = $db->saveScrapedData($url, $dates);
    if (!$saved) {
        error_log("Erreur insertion données pour $url");
    }
}

echo "Données insérées avec succès.";
