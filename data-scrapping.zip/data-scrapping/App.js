const puppeteer = require("puppeteer");
const fetch = require("node-fetch");

class CalendarScraper {
  constructor(url) {
    this.url = url;
    this.browser = null;
    this.page = null;
    this.dateFree = [];
  }

  async init() {
    this.browser = await puppeteer.launch({ headless: true });
    this.page = await this.browser.newPage();
    await this.page.goto(this.url, { waitUntil: "networkidle2" });
  }

  async clickInitialButton() {
    await this.page.waitForSelector("._fz3zdn button");
    await this.page.click("._fz3zdn button");
    await this.page.waitForTimeout(1000);
  }

  async scrapeCalendarDates() {
    const dates = await this.page.$$eval("tr div", (elements) => {
      return elements
        .filter((el) => el.getAttribute("data-is-day-blocked") === "false")
        .map((el) => el.getAttribute("data-testid"));
    });

    this.dateFree.push(...dates);
  }

  async clickNextCalendar() {
    const buttons = await this.page.$$("._qz9x4fc button");
    if (buttons.length > 1) {
      await buttons[1].click();
      await this.page.waitForTimeout(1000);
      return true;
    }
    return false;
  }

  async run() {
    await this.init();
    await this.clickInitialButton();

    let hasNext = true;
    while (hasNext) {
      await this.scrapeCalendarDates();
      hasNext = await this.clickNextCalendar();
    }

    await this.browser.close();
    return this.dateFree;
  }
}

async function scrapeMultiple(urls) {
  const results = [];

  for (const url of urls) {
    const scraper = new CalendarScraper(url);
    const datesDisponibles = await scraper.run();
    results.push({
      url: url,
      dateFree: datesDisponibles,
    });
  }

  return results;
}

(async () => {
  const urls = [
    "https://www.airbnb.fr/rooms/44470454?source_impression_id=p3_1752238384_P3FR_9q4lArRcGkY",
  ];

  const allData = await scrapeMultiple(urls);

  const response = await fetch("/index.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(allData),
  });

  const result = await response.text();
  console.log("Réponse du serveur PHP :", result);
})();
