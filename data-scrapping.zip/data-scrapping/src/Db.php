<?php

namespace App;

class Db
{
    private $host;
    private $dbname;
    private $username;
    private $password;
    private $port;
    private $pdo;

    public function __construct(
        $host = '109.234.165.134',
        $dbname = 'sumi9348_data_scrap',
        $username = 'sumi9348_dev',
        $password = '@8F6eey1gV!hYFeR',
        $port = 3306
    ) {
        $this->host = $host;
        $this->dbname = $dbname;
        $this->username = $username;
        $this->password = $password;
        $this->port = $port;
    }

    public function connect()
    {
        if ($this->pdo) return $this->pdo;

        $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->dbname};charset=utf8mb4";

        try {
            $this->pdo = new \PDO($dsn, $this->username, $this->password, [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC
            ]);
            return $this->pdo;
        } catch (\PDOException $e) {
            die("Erreur de connexion à la base de données : " . $e->getMessage());
        }
    }

    public function query($sql, $params = [])
    {
        $pdo = $this->connect();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function insertUrl(string $url): int
    {
        $pdo = $this->connect();

        $result = $this->query("SELECT id FROM airbnb_url WHERE url = ?", [$url]);
        if (!empty($result)) {
            return (int)$result[0]['id'];
        }

        $stmt = $pdo->prepare("INSERT INTO airbnb_url (url) VALUES (?)");
        $stmt->execute([$url]);
        return (int)$pdo->lastInsertId();
    }

    public function insertDateFree(int $url_id, array $dates): bool
    {
        $pdo = $this->connect();

        $datesJson = json_encode($dates);
        $stmt = $pdo->prepare("INSERT INTO date_free (url_id, dates_json) VALUES (?, ?)");
        return $stmt->execute([$url_id, $datesJson]);
    }

    public function saveScrapedData(string $url, array $dates): bool
    {
        $url_id = $this->insertUrl($url);
        return $this->insertDateFree($url_id, $dates);
    }
}
